My original submission was the Unity Project 4: Complex State Machine assignment
I changed the gameplay to have animations that accommodate moving around, while sneaking has a separate animation.
I tried to update the walls of the maze to be cleaner, but something with the versions of Unity keeps messing with them.
Use WASD or the arrow keys to move and shift to sneak.
Cat picture taken from https://tenor.com/search/cat-stare-gifs and it's referred to as "excuse-me-cat".